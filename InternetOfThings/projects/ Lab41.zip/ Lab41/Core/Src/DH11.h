//#include "stdint.h"
//#include "main.h"
//#include "stm32f4xx_hal_tim.h."

//#define DHT11_PORT GPIOD
//#define DHT11_PIN GPIO_PIN_11
//
//uint8_t RHI, RHD, TCI, TCD, SUM;
//uint32_t pMillis, cMillis;

#define DHT11_PORT GPIOA
#define DHT11_PIN GPIO_PIN_3

#ifndef SRC_DH11_H_
#define SRC_DH11_H_

	void DHT11_config_to_in(void);
	void DHT11_init();
	uint8_t DHT11_Check(void);

	uint8_t DHT11_Read_Bit(void);
	uint8_t DHT11_Read_Byte(void);
	uint8_t DHT11_Read_Data(uint8_t* u8P_temp, uint8_t* u8P_humi);

//void microDelay (uint16_t delay, TIM_HandleTypeDef htim1);
//uint8_t DHT11_Start (TIM_HandleTypeDef htim1);
//uint8_t DHT11_Read (TIM_HandleTypeDef htim1);
//char DHT11_GetData(TIM_HandleTypeDef htim1, float* data);

#endif /* SRC_LCD1602_H_ */
