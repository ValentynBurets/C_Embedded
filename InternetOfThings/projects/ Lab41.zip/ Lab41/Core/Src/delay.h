#ifndef DELAY_H
#define DELAY_H

	static TIM_HandleTypeDef* objSP_delay_timer;
	void delay_init(TIM_HandleTypeDef* objLP_timer);
	void delay_ms(uint32_t u32L_time_ms);
	void delay_us(uint32_t u32L_time_us);

#endif /* SRC_DELAY_H_ */
