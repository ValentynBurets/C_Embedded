/*
 * DH11.c
 *
 *  Created on: Nov 2, 2021
 *      Author: Valentyn
 */


#include "DH11.h"



void DHT11_config_to_in(void)
{
 GPIO_InitTypeDef objL_init_struct;
 objL_init_struct.Pin = DHT11_PIN;
 objL_init_struct.Mode = GPIO_MODE_INPUT;
 objL_init_struct.Pull = GPIO_NOPULL;
 HAL_GPIO_Init(DHT11_PORT, &objL_init_struct);
}
void DHT11_config_to_out(void)
{
 GPIO_InitTypeDef objL_init_struct;
 HAL_GPIO_WritePin(objSP_sensor_port, u16L_sensor_pin, GPIO_PIN_SET);
 objL_init_struct.Pin = DHT11_PIN;
 objL_init_struct.Mode = GPIO_MODE_OUTPUT_PP;
 objL_init_struct.Pull = GPIO_PULLUP;
 objL_init_struct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
 HAL_GPIO_Init(DHT11_PORT, &objL_init_struct);
}

void DHT11_init()
{
	__HAL_RCC_GPIOC_CLK_ENABLE();
}

uint8_t DHT11_Check(void)
{
 uint16_t u16L_retry = 0;
 DHT11_config_to_in();
 while ((HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin) == GPIO_PIN_RESET) &&
u16L_retry < 100)
 {
 u16L_retry++;
 delay_us(1);
 };
 if(u16L_retry >= 100)
 {
 return 1;
 }
 u16L_retry = 0;
 while ((HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin) == GPIO_PIN_SET) &&
u16L_retry < 100)
 {
 u16L_retry++;
 delay_us(1);
 };
 if(u16L_retry >= 100)
 {
 return 1;
 }
 return 0;
}

uint8_t DHT11_Read_Bit(void)
{
 uint16_t u16L_retry = 0;
 while ((HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin) == GPIO_PIN_RESET) &&
u16L_retry < 60)
 {
 u16L_retry++;
 delay_us(1);
 }
 if (u16L_retry > 60)
 {
 return 0xFF;
 }
 u16L_retry = 0;
 while ((HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin) == GPIO_PIN_SET) &&
u16L_retry < 80)
 {
 u16L_retry++;
 delay_us(1);
 }
 return u16L_retry < 30 ? 0 : 1;
}

uint8_t DHT11_Read_Byte(void)
{
 uint8_t u8L_data;
 u8L_data = 0;
 for (uint8_t u8L_i = 0; u8L_i < 8; u8L_i++)
 {
 u8L_data <<= 1;
 u8L_data |= HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin);
 }
 return u8L_data;
}

uint8_t DHT11_Read_Data(uint8_t* u8P_temp, uint8_t* u8P_humi){
	uint8_t u8PL_buf[5];
	uint16_t u16L_retry = 0;
	DHT11_config_to_out();
	DHT11_Rst();
 	 if (DHT11_Check() != 0){
 		 return 1;
 	 }

 	 for (uint8_t u8_i = 0; u8_i < 5; u8_i++){
 		 u8PL_buf[u8_i] = DHT11_Read_Byte();
 	 }

 	 bool bL_has_error = true;

 	 if((u8PL_buf[0] + u8PL_buf[1] + u8PL_buf[2] + u8PL_buf[3]) == u8PL_buf[4]){
 		 *u8P_humi = u8PL_buf[0];
 		 *u8P_temp = u8PL_buf[2];
 		 bL_has_error = false;
 	 }

 	 if (!bL_has_error){
 		 while ((HAL_GPIO_ReadPin(objSP_sensor_port, u16L_sensor_pin) == GPIO_PIN_RESET) && u16L_retry < 60){
 			 u16L_retry++;
 			 delay_us(1);
 		 }
 		 if (u16L_retry > 60){
 			 bL_has_error = true;
 		 }
 	 }
 	 return bL_has_error ? 1 : 0;
}

//
//void microDelay (uint16_t delay, TIM_HandleTypeDef htim1)
//{
//  __HAL_TIM_SET_COUNTER(&htim1, 0);
//  while (__HAL_TIM_GET_COUNTER(&htim1) < delay);
//}
//
//uint8_t DHT11_Start (TIM_HandleTypeDef htim1)
//{
//  uint8_t Response = 0;
//  GPIO_InitTypeDef GPIO_InitStructPrivate = {0};
//  GPIO_InitStructPrivate.Pin = DHT11_PIN;
//  GPIO_InitStructPrivate.Mode = GPIO_MODE_OUTPUT_PP;
//  GPIO_InitStructPrivate.Speed = GPIO_SPEED_FREQ_LOW;
//  GPIO_InitStructPrivate.Pull = GPIO_NOPULL;
//  HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStructPrivate); // set the pin as output
//
//  HAL_GPIO_WritePin (DHT11_PORT, DHT11_PIN, 0);   // pull the pin low
//  HAL_Delay(20);   // wait for 20ms
//
//  HAL_GPIO_WritePin (DHT11_PORT, DHT11_PIN, 1);   // pull the pin high
//  microDelay (30, htim1);   // wait for 30us
//
//  GPIO_InitStructPrivate.Mode = GPIO_MODE_INPUT;
//  GPIO_InitStructPrivate.Pull = GPIO_PULLUP;
//  HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStructPrivate); // set the pin as input
//  microDelay (40, htim1);
//  if (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)))
//  {
//    microDelay (80, htim1);
//    if ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN))) Response = 1;
//  }
//  pMillis = HAL_GetTick();
//  cMillis = HAL_GetTick();
//  while ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)) && pMillis + 2 > cMillis)
//  {
//    cMillis = HAL_GetTick();
//  }
//  return Response;
//}
//
//uint8_t DHT11_Read (TIM_HandleTypeDef htim1)
//{
//  uint8_t a,b;
//  for (a=0;a<8;a++)
//  {
//    pMillis = HAL_GetTick();
//    cMillis = HAL_GetTick();
//    while (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)) && pMillis + 2 > cMillis)
//    {  // wait for the pin to go high
//      cMillis = HAL_GetTick();
//    }
//    microDelay (40, htim1);   // wait for 40 us
//    if (!(HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)))   // if the pin is low
//      b&= ~(1<<(7-a));
//    else
//      b|= (1<<(7-a));
//    pMillis = HAL_GetTick();
//    cMillis = HAL_GetTick();
//    while ((HAL_GPIO_ReadPin (DHT11_PORT, DHT11_PIN)) && pMillis + 2 > cMillis)
//    {  // wait for the pin to go low
//      cMillis = HAL_GetTick();
//    }
//  }
//  return b;
//}
//
//char DHT11_GetData(TIM_HandleTypeDef htim1, float* data) {
//	if (DHT11_Start(htim1)) {
//		RHI = DHT11_Read(htim1); // Relative humidity integral
//		RHD = DHT11_Read(htim1); // Relative humidity decimal
//		TCI = DHT11_Read(htim1); // Celsius integral
//		TCD = DHT11_Read(htim1); // Celsius decimal
//		SUM = DHT11_Read(htim1); // Check sum
//
//		if (RHI + RHD + TCI + TCD == SUM) {
//			// Temperature in celsius
//			data[0] = (float) TCI + (float) (TCD / 10.0);
//
//			// Humidity
//			data[1] = (float) RHI + (float) (RHD / 10.0);
//		}else{
//			return -1;
//		}
//		return 1;
//	}
//	return -1;
}
